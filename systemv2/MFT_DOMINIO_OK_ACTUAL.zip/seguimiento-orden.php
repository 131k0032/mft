<!DOCTYPE html>
<style>
    table{
      font-size:12px;

    }

</style>
<?php include "../db_conexion.php"   ?>
<html lang="en">

<head>





    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MFTSYS | Mayan Fantasy Tours <?php echo $VAR_VERSION ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div id="cober"  name="cober"  style=" position: fixed; top:0px; left: 0px; background-color: rgba(255, 255, 255, .8); height:120%; width:2350px; border:0px solid red; z-index:2000">
        <div style="position:absolute; top:50%; left:25%">

          <div style="text-align:center">
            <span class="fa fa-refresh fa-spin fa-3x fa-fw"></span>
         <br><br><b>PROCESANDO...</b></div>
         </div>
</div>



    <div id="wrapper">

        <!-- Navigation -->
        <?php include "nav.php" ?>

        <div id="page-wrapper" style="width:2200px">
            <div class="row">&nbsp;
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12" style="width:2200px">
                    <div class="panel panel-default">
                        <div class="panel-heading">
<?php

                                $VAR_AL ="";
                                $VAR_EST ="Todos";

                                $VAR_DEL = date("Y-m-d");
                                $VAR_OPE = "Todos";
                                $VAR_TIP = "Todos";
                                $VAR_AGEN = "Todos";
                                $VAR_NOEC = "Todos";



                                if(isset($_POST["txtdel"])){ $VAR_DEL = $_POST["txtdel"]; }
                                $sqlf="select * from _transfers where num > 0 and date1 ='".$VAR_DEL."' ";
                                if(isset($_POST["txtoper"])){  if($_POST["txtoper"]!="Todos")   { $VAR_OPE = $_POST["txtoper"] ; $sqlf= $sqlf." and (oper = '".$_POST["txtoper"]."' ) "; }}
                                if(isset($_POST["txttipo"])){  if($_POST["txttipo"]!="Todos")   { $VAR_TIP = $_POST["txttipo"] ; $sqlf= $sqlf." and tipo = '".$_POST["txttipo"]."'  "; }}
                                if(isset($_POST["txtagen"])){  if($_POST["txtagen"]!="Todos")   { $VAR_AGEN = $_POST["txtagen"] ; $sqlf= $sqlf." and agen = '".$_POST["txtagen"]."'  "; }}
                                if(isset($_POST["txtnoec"])){  if($_POST["txtnoec"]!="Todos")   { $VAR_NOEC = $_POST["txtnoec"] ; $sqlf= $sqlf." and noec = '".$_POST["txtnoec"]."'  "; }}

                                $sqlf = $sqlf . " order by date1, time1, id";
                                //  echo $sqlf;

                               if(isset($_POST["txtacc"])){

                                    if($_POST["txtacc"]=="cerrarall"){

                                          $sqlc="update   _transfers set estatus ='cerrada' where  estatus = 'abierta' and num > 0 and date1 ='".$_POST["txtdel"]."' ";
                                          if(isset($_POST["txtoper"])){  if($_POST["txtoper"]!="Todos")   {   $sqlc= $sqlc." and (oper = '".$_POST["txtoper"]."' ) "; }}
                                          if(isset($_POST["txttipo"])){  if($_POST["txttipo"]!="Todos")   {   $sqlc= $sqlc." and tipo = '".$_POST["txttipo"]."'  "; }}
                                          if(isset($_POST["txtagen"])){  if($_POST["txtagen"]!="Todos")   {   $sqlc= $sqlc." and agen = '".$_POST["txtagen"]."'  "; }}
                                          if(isset($_POST["txtnoec"])){  if($_POST["txtnoec"]!="Todos")   {   $sqlc= $sqlc." and noec = '".$_POST["txtnoec"]."'  "; }}

                                        // echo $sqlc;

                                        adoexecute($sqlc);
                                        

                                    }

                               }



?>

                           <H2> ORDENES DE SERVICIO</H2>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">

                        <div class="col-lg-8" style="padding-bottom:10px" >

                        <div class="row">
                        <form method="post"  id="formulario" name="formulario">
                            <input name="txtrep" id="txtrep" type="hidden">
                            <input name="txtacc" id="txtacc" type="hidden">


                            <div class="col-lg-2" >
                                <label>Fecha</label>
                                <input class="form-control"   name="txtdel" type="date" value="<?php echo $VAR_DEL ?>" />
                            </div>



                             <?php

                                $sqlf1= "select oper from _transfers where oper <> '' and date1 = '".$VAR_DEL."'  group by oper order by oper" ;


                                 ?>
                                    <div class="col-lg-2" >
                                        <label>Operador</label>
                                        <select class="form-control"     name="txtoper" >
                                               <option value="Todos">Todos</option>
                                               <option value="" <?php if($VAR_OPE==""){echo "selected";}?> >Vacios</option>
                                    <?php

                                        $rsf1 = adoopenrecordset($sqlf1);
                                        while($rstempf1 = mysql_fetch_array($rsf1)){
                                          if($VAR_OPE==$rstempf1["oper"]){$VAR_XX = "selected";}else{$VAR_XX="";}
                                    ?>
                                         <option <?php echo $VAR_XX ?> ><?php echo $rstempf1["oper"] ?></option>
                                    <?php
                                        }
                                    ?>


                                        </select>
                                    </div>



                                    <div class="col-lg-2" >
                                        <label>Agencia</label>
                                        <select class="form-control"   name="txtagen" >
                                               <option value="Todos">Todos</option>
                                               <option value="" <?php if($VAR_AGEN==""){echo "selected";}?> >Vacios</option>
                                    <?php
                                        $sqlf1= "select * from _clientes order by cli_nomb " ;
                                        $rsf1 = adoopenrecordset($sqlf1);
                                        while($rstempf1 = mysql_fetch_array($rsf1)){
                                          if($VAR_AGEN==$rstempf1["cli_nomb"]){$VAR_XX = "selected";}else{$VAR_XX="";}
                                    ?>
                                         <option <?php echo $VAR_XX ?> ><?php echo $rstempf1["cli_nomb"] ?></option>
                                    <?php   }  ?>

                                        </select>
                                    </div>



                                        <div class="col-lg-2">
                                            <div class="form-group">
                                                <label>Tipo Servicio</label>
                                                    <select class="form-control"   id="txttipo" name="txttipo">
                                                          <option   value="Todos"    >Todos</option>
                                                          <option <?php  if($VAR_TIP=="ll")  {echo  "selected";}  ?> value="ll"    >LL - Llegada</option>
                                                          <option <?php  if($VAR_TIP=="sl")  {echo  "selected";}  ?> value="sl"    >SL - Salida</option>
                                                          <option <?php  if($VAR_TIP=="tr")  {echo  "selected";}  ?> value="tr"    >TR - Transfer</option>
                                                          <option <?php  if($VAR_TIP=="ow")  {echo  "selected";}  ?> value="ow"    >OW - One Way</option>
                                                          <option <?php  if($VAR_TIP=="rt")  {echo  "selected";}  ?> value="rt"    >RT - Round Trip</option>
                                                          <option <?php  if($VAR_TIP=="tour"){echo  "selected";}  ?> value="tour"  >TOUR - Tour</option>
                                                          <option <?php  if($VAR_TIP=="sa")  {echo  "selected";}  ?> value="sa"    >SA - Servicio Abierto</option>
                                                          <option <?php  if($VAR_TIP=="cir") {echo  "selected";}  ?> value="cir"   >CIR - Circuito</option>
                                                    </select>
                                            </div>
                                        </div>

                                    <div class="col-lg-2" >
                                        <label>No. Eco</label>
                                        <select class="form-control"   name="txtnoec" >
                                               <option>Todos</option>
                                    <?php
                                        $sqlf1= "select noec from _transfers where noec <> ''  and date1 = '".$VAR_DEL."' group by noec order by noec" ;
                                        $rsf1 = adoopenrecordset($sqlf1);
                                        while($rstempf1 = mysql_fetch_array($rsf1)){
                                          if($VAR_NOEC==$rstempf1["noec"]){$VAR_XX = "selected";}else{$VAR_XX="";}
                                    ?>
                                         <option <?php echo $VAR_XX ?> ><?php echo $rstempf1["noec"] ?></option>
                                    <?php
                                        }
                                    ?>


                                        </select>
                                    </div>




                             <!--
                            <div class="col-lg-2" >
                                <label>Al</label>
                                <input class="form-control" onchange="document.formulario.submit()" name="txtal" type="date" value="<?php echo $VAR_AL ?>" />
                            </div>
                                -->

                                <!--
                            <div class="col-lg-2" >
                                <label>Estatus</label>
                                <select class="form-control" onchange="document.formulario.submit()"   name="txtest" >


                                    <option <?php if($VAR_EST=="Todos"){echo "selected"; }?> value="" >Todos</option>
                                    <option <?php if($VAR_EST=="abierta"){echo "selected"; }?> value="abierta" >Abierta</option>


                                    <option <?php if($VAR_EST=="cerrada"){echo "selected"; }?> value="cerrada" >Cerrada</option>

                                </select>
                            </div>
                               -->
                               <div class="col-lg-12">
                                <div class="col-lg-6">
                                    <div class="col-lg-4"><button style=" display:  inline !important" type="submit" class="btn btn-primary btn-lg btn-block" >Filtrar</button></div>
                                    <div class="col-lg-7"><button style=" display:  inline !important" type="button"  name="btncerrarall" id="btncerrarall" class="btn btn-success btn-lg btn-block" ><li class="fa fa-check"></li> Cerrar todas las órdenes</button></div>



                                </div>


                               </div>

                          </form>
                          </div>
                         <div class="row" style="border:0px solid red">
                            <form method="post" action="impresion-cierre-orden.php" target="_blank" >

                                <div class="col-lg-2"  style="padding-top:10px">
                                <fieldset style="border:1px solid silver; padding:2px; ; width:300%">
                                    <div style="float:left;width:50%;padding:2px">
                                        <button style=" display:  inline !important" type="submit" class="btn btn-primary btn-lg btn-block" >Imprimir</button>
                                    </div>
                                    <div style="float:left;width:50%;padding:2px; vertical-align: middle">
                                        <select class="form-control" name="txtoper" style=" display:  inline !important">
                                                <option value="Todos">Todos</option>
                                                <option value="">Vacios</option>
                                                <?php
                                                    $sql = "select oper from _transfers group by oper order by oper ";
                                                    $rs = adoopenrecordset($sql);
                                                    while($rstemp = mysql_fetch_array($rs)){
                                                        ?>
                                                            <option value="<?php echo $rstemp["oper"] ?>"><?php echo $rstemp["oper"] ?></option>
                                                <?php
                                                    }
                                                ?>
                                        </select>
                                    </div>

                                </fieldset>

                              </div>
                                        <textarea style="visibility: hidden;height:0px;width:0px" name="txtsql" id="txtsql" cols="0" rows="0"><?php echo $sqlf ?></textarea>
                                        <textarea style="visibility: hidden;height:0px;width:0px" name="txtsql2" id="txtsql2" cols="0" rows="0"><?php
                                        echo
                                        $VAR_DEL  ."|".
                                        $VAR_AL   ."|".
                                        $VAR_EST  ."|"
                                         ?></textarea>
                            </form>
                          </div>

                        </div>
                        <div class="col-lg-12"><hr></div>

                            <table width="100%" data-order='[[ 0, "desc" ]]' data-page-length='50' class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>&nbsp;</th>
                                        <th>&nbsp;</th>
                                        <th>#</th>
                                        <th>No.Ord</th>
                                        <th>Vehículo</th>
                                        <th>No.Eco</th>
                                        <th>Placas</th>
                                        <th>Operador</th>
                                      <!--  <th>Vehículo</th> -->
                                        <th>Agencia</th>
                                        <th>Servicio</th>
                                        <th>PAX</th>
                                        <th>Nombre</th>
                                   <!--     <th>Hab</th> -->
                                        <th>Hora</th>
                                        <th>Pick up</th>
                                        <th>Drop off</th>
                                        <th>Vuelo</th>
                                        <th>Cve</th>
                                         <th>Anexa</th>
                                        <th>Comentarios</th>
                                        <th>Apoyo</th>

                                        <th>Cta</th>
                                        <th>Estatus</th>
                                        <th>Captura</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php


                                      $i = 0;

                                      $rsf = adoopenrecordset($sqlf);
                                      while($rstempf = mysql_fetch_array($rsf)){

                                        if($rstempf["estatus"]=="terminada") { $VAR_COLOR ="#D4FFA8";}
                                        if($rstempf["estatus"]=="cancelada") { $VAR_COLOR ="#FF6161";}
                                        if($rstempf["estatus"]=="abierta") { $VAR_COLOR ="";}
                                        if($rstempf["estatus"]=="cerrada") { $VAR_COLOR ="#D4FFA8";}

                                        $VAR_NX = "";

                                        if( date("Y-M-d",$rstempf["num"]) != date("Y-M-d")  ){
                                            $i = $i + 1;
                                            $VAR_NX = $i;

                                        }


                                      ?>

                                            <tr  style="background-color:<?php echo $VAR_COLOR ?>"  style="cursor:pointer;" id="row<?php echo $rstempf["id"] ?>" >
                                            <td><a href="agregar-servicio.php?t=<?php echo $rstempf["id"] ?>"><?php echo $rstempf["id"] ?></a></td>
                                            <td>
                                                <?php if($rstempf["estatus"]=="abierta"){ ?>

                                                    <button class="btn btn-success "   title="terminar orden" id="bt<?php echo $rstempf["id"] ?>"
                                                    onclick="cerrar(<?php echo $rstempf["id"] ?>)" >
                                                    <span class="fa fa-check"  ></span></button><p id="p"></p>
                                                <?php } ?>
                                            </td>





                                            <td>
                                                <?php if($rstempf["estatus"]=="abierta"){ ?>

                                                    <button class="btn btn-danger " title="cancelar orden" id="btc<?php echo $rstempf["id"] ?>"
                                                    onclick="cancelar(<?php echo $rstempf["id"] ?>)" >
                                                    <span class="fa fa-ban"  ></span></button><p id="p"></p>
                                                <?php } ?>
                                            </td>

                                            <td style="text-align:center">
                                                   <!--     <a href="agregar-servicio.php?t=<?php echo $rstempf["id"] ?>"><?php echo $rstempf["consec"] ?></a>   -->
                                                        <a href="agregar-servicio.php?t=<?php echo $rstempf["id"] ?>"><?php echo $VAR_NX ?></a>
                                            </td>


                                            <td align="center">
                                                <?php // echo $rstempf["come"]  ?>
                                                <input name="noord" style="text-align:center;width:50px" id="<?php echo $rstempf["id"] ?>" value="<?php echo $rstempf["noord"] ?>" >
                                            </td>


                                        <td><?php echo $rstempf["tipo_veh"] ?></td>
                                        <td><?php echo $rstempf["noec"] ?></td>

                                        <td><?php echo $rstempf["plac"] ?></td>
                                        <td><?php echo $rstempf["oper"] ?></td>
                                      <!--  <td><?php echo $rstempf["vehic"] ?></td> -->
                                        <td><?php echo $rstempf["agen"] ?></td>
                                            <td><?php echo strtoupper($rstempf["tipo"]) ?></td>
                                            <td><?php echo ($rstempf["adul"].".".$rstempf["chil"].".".$rstempf["enfa"]) ?></td>
                                            <td><?php echo $rstempf["name"] ?></td>
                                        <!--    <td><?php echo $rstempf["room"] ?></td>   -->
                                            <td><?php echo $rstempf["time1"] ?></td>
                                            <td><?php echo substr($rstempf["orig1"],0,25) ?></td>
                                            <td><?php echo substr(strtoupper($rstempf["dest1"]),0,25) ?></td>
                                            <td><?php echo $rstempf["vuel1"]  ?></td>
                                            <td style="background-color: #66FF00"><b>CC<?php echo $rstempf["cve"]  ?>BB<?php echo $rstempf["cve2"]  ?></b></td>
                                            <td style="text-align:center">
                                          <?php
                                                                $nombre_fichero = '_files/'.$rstempf["id"].'.pdf';
                                                                // echo  '_files/'.$rstempf["id"].'.pdf';
                                                                if (file_exists($nombre_fichero)) {
                                                                     echo "<a target='_blank' href='_files/".$rstempf["id"].".pdf'><span class='fa fa-file'></span></a>";
                                                                } else {
                                                                     //echo "El fichero $nombre_fichero no existe";
                                                                }


                                             ?>
                                             </td>
                                            <td>
                                                <?php // echo $rstempf["come"]  ?>
                                                <textarea name="come" id="<?php echo $rstempf["id"] ?>" ><?php echo $rstempf["come"] ?></textarea>
                                            </td>
                                            <td>
                                                <?php // echo $rstempf["come"]  ?>
                                                <textarea name="apoyo" id="<?php echo $rstempf["id"] ?>" ><?php echo $rstempf["apoyo"] ?></textarea>
                                            </td>

                                            <td><?php

                                              if($rstempf["cta"]=="cxc"){ echo "Cliente";}
                                              if($rstempf["cta"]=="cxp"){ echo "Proveedor";}
                                              if($rstempf["cta"]=="cor"){ echo "Cortesia";}



                                              ?></td>
                                              <td><?php echo strtoupper($rstempf["estatus"])  ?></td>
                                              <td><?php echo date("Y-M-d",$rstempf["num"])  ?></td>
                                        </tr>

                                  <?php
                                      }


                                    ?>

                                </tbody>
                            </table>
                                <button id="guardar" type="submit" class="btn btn-primary btn-lg btn-block" >Guardar</button>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <!-- /.row -->

            <!-- /.row -->

            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

     <script src="js/jquery.cookie.js"></script>


    <!-- Page-Level Demo Scripts - Tables - Use for reference -->


<script src="alertifyjs/alertify.min.js"></script>
<link rel="stylesheet" href="alertifyjs/css/alertify.min.css" />
<link rel="stylesheet" href="alertifyjs/css/themes/default.min.css" />







    <script>



    $(document).ready(function() {



                $('#btncerrarall').click(function(){
                alertify.confirm('MFTSYS','¿Desea cerrar todas las ordenes del listado?',function(){

                    document.formulario.txtacc.value="cerrarall";
                    document.formulario.submit();

                },function(){


                });


            })


       $('#cober').hide();




        $('#dataTables-example').DataTable({

            "columnDefs": [
                { "swidth": "10px", "targets": 0 },
                { "swidth": "2%", "targets": 0 },
                { "swidth": "2%", "targets": 0 },
                { "swidth": "2%", "targets": 0 },
                { "swidth": "2%", "targets": 0 },
                { "swidth": "50%", "targets": 0 }
              ],
            bSort:false

        });
    });


  function Guardar() {

  window.scrollTo(0, 0);
  $('#cober').show();


      /*      $('input[name^="costo"]').each(function()       { var arch = 'update-operador.php?c=costo&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });
            $('input[name^="gasolina"]').each(function()    { var arch = 'update-operador.php?c=gasolina&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });
            $('input[name^="sueldo"]').each(function()      { var arch = 'update-operador.php?c=sueldo&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });
            $('input[name^="litros"]').each(function()      { var arch = 'update-operador.php?c=litros&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });
            $('input[name^="ki"]').each(function()          { var arch = 'update-operador.php?c=ki&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });
            $('input[name^="kf"]').each(function()          { var arch = 'update-operador.php?c=kf&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });
            $('input[name^="estimado"]').each(function()    { var arch = 'update-operador.php?c=estimado&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });
       */

            $('input[name^="noord"]').each(function()    { var arch = 'update-operador.php?c=noord&val='+$(this).val()+'&i='+$(this).attr('id');  $.get(arch);  });


            $('textarea[name^="come"]').each(function() {
                var arch = 'update-operador.php?c=come&val='+$(this).val()+'&i='+$(this).attr('id');
               // alert(arch);
                $.get(arch);
            });

            $('textarea[name^="apoyo"]').each(function() {
                var arch = 'update-operador.php?c=apoyo&val='+$(this).val()+'&i='+$(this).attr('id');
               // alert(arch);
                $.get(arch);
            });






                   alertify.success("Asignaciones Guardadas");


                   var timeoutId = setTimeout(function(){
                       $('#cober').hide()
                    },7000);




         }



    $("#guardar").click(
          function(){
             Guardar();
         }
    );


    function cerrar(ID){
             alertify.confirm('MFTSYS', 'Desea marcar la orden como terminada?', function(){
              var arch = 'update-orden-terminada.php?&i='+ID;
                   $.get(arch);

                   Guardar();

                 //  $("#row"+ID).hide('slow');
                 //  $("#row"+ID).hide('slow');

                    $("#row"+ID).css('background-color', '#D4FFA8');


                   $("#bt"+ID).hide();
                   $("#btc"+ID).hide();
                   $("#p"+ID).text('Cerrada');


            // alertify.success('Orden Cerrada')
            }
                , function(){

                    //alertify.error('Cancel')
                });



    };



    function cancelar(ID){
             alertify.confirm('MFTSYS', 'Desea marcar la orden como cancelada?', function(){
              var arch = 'update-orden-cancelada.php?&i='+ID;
                   $.get(arch);

                 //  Guardar();

                 //  $("#row"+ID).hide('slow');
                 //  $("#row"+ID).hide('slow');

                    $("#row"+ID).css('background-color', '#FF6161');


                   $("#btc"+ID).hide();
                   $("#bt"+ID).hide();
                   $("#p"+ID).text('Cancelada');


            // alertify.success('Orden Cerrada')
            }
                , function(){

                    //alertify.error('Cancel')
                });



    };



    </script>



</body>

</html>
